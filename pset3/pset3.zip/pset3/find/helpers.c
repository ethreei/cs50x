/**
 * helpers.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Helper functions for Problem Set 3.
 */
       
#include <cs50.h>

#include "helpers.h"

#include <math.h>

/**
 * Returns true if value is in array of n values, else false.
 */
bool search(int value, int values[], int n)
{
    // TODO: implement a searching algorithm
    // Binary Search
    int mid_point = floor(n/2); // Determine middle of array
    int lower_bound = 0; // Determine lower bound of array
    int upper_bound = n-1; // Determine upper bound of array
    int array_size = n-1; // Determine length of array
    
    while (array_size > 2)
    {
        mid_point = floor((upper_bound - lower_bound)/2 + lower_bound);
        if (value == values[mid_point])
        {
            return true;
        }
        else if (value > values[mid_point])
        {
            lower_bound = mid_point + 1;
        
        }
        else
        {
            upper_bound = mid_point - 1;
        }
        array_size = upper_bound - lower_bound;
    }
    if (value == values[lower_bound] || value == values[upper_bound] || value == values[mid_point])
    {
        return true;
    }
    return false;
}

/**
 * Sorts array of n values.
 */
void sort(int values[], int n)
{
    // TODO: implement an O(n^2) sorting algorithm
    // Selection Sort

    // Loop through array from 0 to n
    for (int i = 0; i < n; i++)
    {
        // Store first value of array as comparison
        int initial_lowest_value = values[i];
        int current_lowest_value = initial_lowest_value;
        int array_value_lowest_value = 0;
        
        // Loop through array from i to n
        for (int j = i; j < n; j++)
        {
            // Store the lowest value of the array
            if (values[j] < current_lowest_value)
            {
                current_lowest_value = values[j];
                array_value_lowest_value = j;
            }
        }
        // Replace array with lowest value
        if (initial_lowest_value != current_lowest_value)
        {
            values[i] = current_lowest_value;
            values[array_value_lowest_value] = initial_lowest_value;            
        }
    }
    return;
}