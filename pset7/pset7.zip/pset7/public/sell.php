<?php

    // configuration
    require("../includes/config.php");

    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("sell.php", ["title" => "Sell"]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // validate submission
        if (empty($_POST["symbol"]))
        {
            apologize("You must provide a ticker symbol.");
        }
        else if ($_POST["quantity"] < 1)
        {
            apologize("You must sell at least 1 share.");
        }
        
        $current_stocks = CS50::query("SELECT shares FROM portfolios WHERE user_id = ? and symbol = ?", $_SESSION["id"], $_POST["symbol"]);
        
        if (!empty($current_stocks))
        {
            if ($_POST["quantity"] <= $current_stocks[0]["shares"])
            {
                CS50::query("UPDATE portfolios SET shares = ? WHERE user_id = ? AND symbol = ?", ($current_stocks[0]["shares"] - $_POST["quantity"]), $_SESSION["id"], $_POST["symbol"]);
                $stock = lookup($_POST["symbol"]);
                CS50::query("UPDATE users SET cash = cash + ? WHERE id = ?", ($stock["price"] * $_POST["quantity"]), $_SESSION["id"]);
                
                $transaction = 'sell';
                CS50::query("INSERT INTO history (user_id, symbol, shares, price, date, transaction) VALUES(?, ?, ?, ?, CURRENT_DATE, ?)", $_SESSION["id"], strtoupper($_POST["symbol"]), $_POST["quantity"], $stock["price"], $transaction);
                
                render("sell_info.php", ["name" => $stock["name"],"price" => $stock["price"], "quantity" => $_POST["quantity"]]);
            }
            else
            {
                apologize("You do now own enough shares to sell this amount.");
            }
        }
        else
        {
            apologize("You do not currently own this stock.");
        }


    }

?>