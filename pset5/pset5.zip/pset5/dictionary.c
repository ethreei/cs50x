/**
 * dictionary.c
 *
 * Computer Science 50
 * Problem Set 5
 *
 * Implements a dictionary's functionality.
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "dictionary.h"

unsigned int hash_words_counter = 0;

/**
 * Returns true if word is in dictionary else false.
 */
bool check(const char* word)
{
    // Put word in lower case & take out any apostrophes
    char word_check[strlen(word)];
    strcpy(word_check, word);
    for(int i = 0; i < strlen(word); i++)
    {
        word_check[i] = tolower(word[i]);
    }
    
    // Put word into hash function
    unsigned int hash_value = hash(word_check); 
    // Mod the hash value by the number of keys in hash table
    hash_value = hash_value % HASHKEYS;
    
    // Temporary node to traverse through
    node* trav_node;
    
    // Go to hash_table pointer and check if pointer exists
    if (hash_table[hash_value])
    {
        
        // Dereference hash_value and check if word is in that node. Loop until trav_node is null
        trav_node = hash_table[hash_value];
        
		while(trav_node != NULL){
			if(strcmp(trav_node->node_word,word_check) == 0)
				return true;
			else
				trav_node = trav_node->next;
		}
        
    }
    else
    {
        return false;
    }
    return false;
}

/**
 * Loads dictionary into memory.  Returns true if successful else false.
 */
bool load(const char* dictionary)
{
    
    // Create file pointer to dictionary
    FILE* hash_fp = fopen(dictionary, "r");
    if (hash_fp == NULL)
    {
        printf("Dictionary file unavailable. \n");
        return false;
    }
    
    // Create char to store word by word and counter
    char word_dict[LENGTH + 1];
    int word_counter = 0;
    unsigned int hash_value;
    
    
    // Loop through each word and store into word
    while(fgets(word_dict, LENGTH+1, hash_fp))
    {
        // Change escape character to null character
        // word_dict[strlen(word_dict)-1] = '\0';
        if(word_dict[0] != '\n')
        {
            char *pos;
            if ((pos=strchr(word_dict, '\n')) != NULL)
            *pos = '\0';
            
            // Put that word into hash function
            hash_value = hash(word_dict);
    
            // Create node to store word
            node* new_node = malloc(sizeof(node));
            
            
            // Mod the hash value by the number of keys in hash table
            hash_value = hash_value % HASHKEYS;
            
            // Put word in node
            strcpy(new_node->node_word,word_dict);
            new_node->next = NULL;
            
            
            // Check if anything is in that key
            if (hash_table[hash_value] != NULL)
            {
                
                // Point new node to same thing hash table is pointing at
                new_node->next = hash_table[hash_value];
                // Point hash table to new node
                hash_table[hash_value] = new_node;
                
            }
            else
            {
                
                // Point hash table to new node
                hash_table[hash_value] = new_node;
                
            }
            
            word_counter++;
            hash_words_counter++;
        }
    }
    
    // Free any leaked memory
    fclose(hash_fp);
    return true;
}

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void)
{
    return hash_words_counter;
}

/**
 * Unloads dictionary from memory.  Returns true if successful else false.
 */
bool unload(void)
{
    // Create temp node to store pointers before freeing memory and delete node which will delete the node
    node* temp_node;
    node* delete_node;
    
    // Loop through the hash_table
    for (int i = 0; i < HASHKEYS; i++)
    {
        // Check if hash_table pointer exists
        if (hash_table[i])
        {
            delete_node = hash_table[i];
                   
                   
            // Put the temp node what node further than delete node, then free the node. Re-assign delete node to that temp_node
    		while(delete_node){
    		    temp_node = delete_node->next;
    			free(delete_node);
    			delete_node = temp_node;
    		}
        }
    }
    
    return true;
}

/**
 * Hash Function designed by Dan Bernstein in djb2 http://www.cse.yorku.ca/~oz/hash.html
 */
 
unsigned int hash(const char* cp)
{
    unsigned int hash = 5381;
    while (*cp)
        hash = 33 * hash ^ (unsigned char) *cp++;
    return hash;
}
