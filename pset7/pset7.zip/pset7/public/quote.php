<?php

    // configuration
    require("../includes/config.php");

    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("quote.php", ["title" => "Quote"]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // validate submission
        if (empty($_POST["quote"]))
        {
            apologize("You must provide a ticket symbol.");
        }

        $stock = lookup($_POST["quote"]);

        // if we found user, check password
        if (count($stock) == 3)
        {
            render("quote_info.php", ["name" => $stock["name"],"price" => $stock["price"]]);
        }

        // else apologize
        apologize("Please enter a valid stock ticker.");
    }

?>