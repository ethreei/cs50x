<div>
    <p> Purchase Confirmed </p>
    <p> <?php print("Stock: ". $name); ?> </p>
    <p> <?php print("Price: ". number_format($price,4)); ?> </p>
    <p> <?php print("Quantity: ". $quantity); ?> </p>
    <p> <?php print("Cash Adjusted: -". number_format($price * $quantity,2)); ?> </p>
</div>
