<?php

    // configuration
    require("../includes/config.php"); 

    $query_position = CS50::query("SELECT * FROM portfolios WHERE user_id = ?", $_SESSION["id"]);
    foreach ($query_position as $row)
    {
        $temp = lookup($row["symbol"]);
        if ($temp != false)
        {
            $position[] = [
                "name" => $temp["name"],
                "symbol" => $temp["symbol"],
                "shares" => $row["shares"],
                "price" => $temp["price"]
                ];
        }
    }

    $cash = CS50::query("SELECT cash FROM users WHERE id = ?", $_SESSION["id"]);
    // render portfolio
    render("portfolio.php", ["title" => "Portfolio", "positions" => $position, "cash" => $cash[0]]);

?>
