<?php

    // configuration
    require("../includes/config.php");

    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("buy.php", ["title" => "Buy"]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // validate submission
        if (empty($_POST["symbol"]))
        {
            apologize("You must provide a ticker symbol.");
        }
        else if ($_POST["quantity"] < 1)
        {
            apologize("You must buy at least 1 share.");
        }
        else if (!preg_match("/^\d+$/", $_POST["quantity"]))
        {
            apologize("You must enter a positive integer");
        }
        
        $stock = lookup($_POST["symbol"]);
        $purchase_order = $stock["price"] * $_POST["quantity"];
        $user = CS50::query("SELECT cash FROM users WHERE id = ? ", $_SESSION["id"]);
        
        if (!empty($stock))
        {
            if ($purchase_order <= $user[0]["cash"])
            {
                $check_stocks = CS50::query("SELECT shares FROM portfolios WHERE id = ? and symbol = ?", $_SESSION["id"], $_POST["symbol"]);
                if (!empty($check_stocks))
                {
                    CS50::query("UPDATE portfolios SET shares = shares + ? WHERE user_id = ? AND symbol = ?", $_POST["quantity"], $_SESSION["id"], $_POST["symbol"]);
                }
                else
                {
                    CS50::query("INSERT INTO portfolios (user_id, symbol, shares) VALUES(?, ?, ?) ON DUPLICATE KEY UPDATE shares = shares + VALUES(shares)", $_SESSION["id"], strtoupper($_POST["symbol"]), $_POST["quantity"]);
                }
                CS50::query("UPDATE users SET cash = cash - ? WHERE id = ?", ($stock["price"] * $_POST["quantity"]), $_SESSION["id"]);
                
                $transaction = 'buy';
                CS50::query("INSERT INTO history (user_id, symbol, shares, price, date, transaction) VALUES(?, ?, ?, ?, CURRENT_DATE, ?)", $_SESSION["id"], strtoupper($_POST["symbol"]), $_POST["quantity"], $stock["price"], $transaction);
                
                render("buy_info.php", ["name" => $stock["name"],"price" => $stock["price"], "quantity" => $_POST["quantity"]]);
            }
            else
            {
                apologize("You do not have enough funds for this purchase.");
            }
        }
        else
        {
            apologize("Please enter a valid ticker symbol.");
        }


    }

?>