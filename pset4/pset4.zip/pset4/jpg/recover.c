/**
 * recover.c
 *
 * Computer Science 50
 * Problem Set 4
 *
 * Recovers JPEGs from a forensic image.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#define FILENAME "card.raw"
typedef uint8_t  BYTE;

int main(void)
{
    
    // Open memory card file
    FILE* inptr = fopen(FILENAME, "r");
    if (inptr == NULL)
    {
        printf("Could not open %s.\n", FILENAME);
        return 1;
    }
    
    // Declare output variables
    char* outfile = malloc(8 * sizeof(char));
    FILE* outptr = NULL;
    BYTE* buffer = malloc(512 * sizeof(BYTE));
    int file_index = 0;
    
    while (fread(buffer, 512, 1, inptr))
    {
        // Read 512 block at a time
        // fread(buffer, 512, 1, inptr);
        
        // Start count of JPG files
        if (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff)
        {
            if (outptr == NULL)
            {
                // Making a new JPG
                sprintf(outfile, "%03d.jpg", file_index);
                
                outptr = fopen(outfile, "a");
                if (outptr == NULL)
                {
                    fclose(inptr);
                    fprintf(stderr, "Could not create %s.\n", outfile);
                    return 3;
                }
                else
                {
                    fwrite(buffer, 512, 1, outptr);
                    file_index ++;
                }
            }
            else
            {
                // Close the file
                fclose(outptr);
                
                // Create new JPG file
                sprintf(outfile, "%03d.jpg", file_index);
                
                outptr = fopen(outfile, "a");
                if (outptr == NULL)
                {
                    fclose(inptr);
                    fprintf(stderr, "Could not create %s.\n", outfile);
                    return 3;
                }
                else
                {
                    fwrite(buffer, 512, 1, outptr);
                    file_index ++;
                }
            }
        }
        else if(outptr != NULL)
        {
            fwrite(buffer, 512, 1, outptr);
        }
    
    } while (!feof(inptr));

    // Free memory
    free(outfile);
    free(buffer);  
    
    return 0;
}
