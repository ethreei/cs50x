<div>
    <p> <?php print("Stock: ". $name); ?> </p>
    <p> <?php print("Price: ". number_format($price,4)); ?> </p>
</div>
