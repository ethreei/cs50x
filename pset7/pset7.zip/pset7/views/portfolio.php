<div>
    <p>Balance: <?php print(number_format($cash["cash"],2)) ?> </p>
    <h2>Current Portfolio</h2>
<table>
    <tr>
        <th>Symbol</th>
        <th>Company</th>
        <th>Shares</th>
        <th>Price</th>
        <th>Market Value</th>
    </tr>
    
    <?php

        foreach ($positions as $position)
        {
            print("<tr>");
            print("<td>" . $position["symbol"] . "</td>");
            print("<td>" . $position["name"] . "</td>");
            print("<td>" . $position["shares"] . "</td>");
            print("<td>" . number_format($position["price"],2) . "</td>");
            print("<td>" . number_format($position["price"] * $position["shares"],2). "</td>");
            print("</tr>");
        }

    ?>
</table>
</div>
