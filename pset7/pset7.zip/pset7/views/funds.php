<form action="funds.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="funds" placeholder="0" type="number" min="1"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit">
                <span aria-hidden="true" class="glyphicon glyphicon-log-in"></span>
                Deposit Funds
            </button>
        </div>
    </fieldset>
</form>
