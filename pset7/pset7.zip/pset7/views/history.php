<div>
    <h2>Transactions</h2>
<table>
    <tr>
        <th>Symbol</th>
        <th>Date</th>
        <th>Type</th>
        <th>Shares</th>
        <th>Price</th>
    </tr>
    <?php

        foreach ($positions as $position)
        {
            print("<tr>");
            print("<td>" . strtoupper($position["symbol"]) . "</td>");
            print("<td>" . $position["date"] = date("F j, Y") . "</td>");
            print("<td>" . $position["transaction"] . "</td>");
            print("<td>" . $position["shares"] . "</td>");
            print("<td>" . number_format($position["price"],2) . "</td>");
            print("</tr>");
        }

    ?>
</table>
</div>
