<?php

    // configuration
    require("../includes/config.php");

    $user_history = CS50::query("SELECT * FROM history WHERE user_id = ?", $_SESSION["id"]);
    if ($user_history == false)
    {
        apologize("There is no historical transactions");
    }

    // render history
    render("history.php", ["title" => "Portfolio", "positions" => $user_history]);

?>